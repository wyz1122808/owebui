<div class=" self-center font-semibold mb-0.5 line-clamp-1 contents">
	<slot />
</div>
