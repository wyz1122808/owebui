<script>
	import Prompts from '$lib/components/workspace/Prompts.svelte';
</script>

<Prompts />
